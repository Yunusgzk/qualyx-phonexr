#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PAYLOAD="${1:-$ROOT/reference_payload}"
for f in "$PAYLOAD"/librendersystemvulkan.so "$PAYLOAD"/libvulkan_freedreno_hlvr.so; do
  if [[ -f "$f" ]]; then
    echo "=== $f ==="
    file "$f"
    echo "-- NEEDED --"
    readelf -d "$f" | grep NEEDED || true
    echo "-- Vulkan/WSI strings --"
    strings "$f" | grep -Ei 'VK_KHR_swapchain|VK_KHR_android_surface|VK_KHR_xcb_surface|VK_KHR_wayland_surface|VK_QCOM|freedreno|Turnip' | sort -u | head -120 || true
  else
    echo "[skip] $f not present"
  fi
done
