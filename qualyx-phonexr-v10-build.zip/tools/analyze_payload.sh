#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DIR="$ROOT/reference_payload/arm64-v8a"
for f in "$DIR"/*.so; do
  echo "### $(basename "$f")"
  file "$f" || true
  readelf -h "$f" 2>/dev/null | grep -E 'Class|Machine|OS/ABI' || true
  readelf -d "$f" 2>/dev/null | grep NEEDED || true
  echo
 done
