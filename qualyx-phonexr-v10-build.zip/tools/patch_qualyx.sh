#!/usr/bin/env bash
set -euo pipefail
IN="$1"; HOST="$2"; RUNTIME="$3"; OUT="$4"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="$ROOT/.patch-work"
rm -rf "$WORK"
mkdir -p "$WORK/unzip/lib/arm64-v8a" "$WORK/out"
unzip -q "$IN" -d "$WORK/unzip"

if [ ! -f "$WORK/unzip/lib/arm64-v8a/libhlvr_host.so" ]; then
  echo 'HATA: Qualyx APK içinde lib/arm64-v8a/libhlvr_host.so bulunamadı.' >&2
  exit 2
fi
cp "$WORK/unzip/lib/arm64-v8a/libhlvr_host.so" "$WORK/unzip/lib/arm64-v8a/libhlvr_host_real.so"
cp "$HOST" "$WORK/unzip/lib/arm64-v8a/libhlvr_host.so"
cp "$RUNTIME" "$WORK/unzip/lib/arm64-v8a/libopenxr_loader.so"

# APK'nın AndroidManifest'i değişmiyor; NativeActivity mevcut Qualyx girişini korur.
# Yeniden paketle.
cd "$WORK/unzip"
zip -qr "$WORK/unsigned.apk" .

BT="${ANDROID_HOME}/build-tools/35.0.0"
mkdir -p "$HOME/.android"
if [ ! -f "$HOME/.android/debug.keystore" ]; then
  keytool -genkeypair -v -keystore "$HOME/.android/debug.keystore" -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Android Debug,O=Android,C=US' >/dev/null 2>&1
fi
"$BT/zipalign" -f 4 "$WORK/unsigned.apk" "$WORK/aligned.apk"
"$BT/apksigner" sign --ks "$HOME/.android/debug.keystore" --ks-pass pass:android --key-pass pass:android --out "$OUT" "$WORK/aligned.apk"
"$BT/apksigner" verify --verbose "$OUT"
echo "OK: $OUT"
