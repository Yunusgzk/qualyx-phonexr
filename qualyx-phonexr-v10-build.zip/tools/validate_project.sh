#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
test -f "$ROOT/CMakeLists.txt"
test -f "$ROOT/app/src/main/AndroidManifest.xml"
test -f "$ROOT/app/src/main/cpp/phonexr_runtime.cpp"
test -f "$ROOT/app/src/main/cpp/phonexr_compat.cpp"
test -f "$ROOT/app/src/main/cpp/openxr/phonexr_openxr_min.h"
grep -q 'phonexr_compat.cpp' "$ROOT/CMakeLists.txt"
grep -q 'xrStringToPath' "$ROOT/app/src/main/cpp/phonexr_runtime.cpp"
grep -q 'VK_QCOM_tile_memory_heap' "$ROOT/app/src/main/cpp/phonexr_runtime.cpp"
for f in "$ROOT"/reference_payload/arm64-v8a/*.so; do readelf -h "$f" | grep -q 'AArch64'; done
echo 'PhoneXR v0.7 validation: OK'
