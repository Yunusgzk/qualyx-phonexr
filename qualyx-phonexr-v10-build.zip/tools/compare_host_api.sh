#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HOST="$ROOT/reference_payload/arm64-v8a/libhlvr_host.so"
for sym in xrCreateInstance xrCreateSession xrCreateSwapchain xrEnumerateSwapchainImages xrAcquireSwapchainImage xrWaitSwapchainImage xrReleaseSwapchainImage xrEndFrame xrStringToPath xrPathToString xrCreateActionSet xrCreateAction xrCreateActionSpace xrGetActionStatePose xrGetActionStateBoolean xrGetActionStateFloat xrGetActionStateVector2f xrApplyHapticFeedback; do
  if ! readelf -Ws "$HOST" | grep "$sym" >/dev/null; then { echo "missing host symbol: $sym"; exit 2; }
  fi
done
echo 'Qualyx host OpenXR API baseline: OK'
