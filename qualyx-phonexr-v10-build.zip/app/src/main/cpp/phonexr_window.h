#pragma once
struct android_app;
struct ANativeWindow;
extern "C" void phonexr_set_android_app(android_app* app);
extern "C" ANativeWindow* phonexr_get_android_window();
