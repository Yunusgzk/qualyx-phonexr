#pragma once
#include <vulkan/vulkan.h>
#include <android/native_window.h>
#include <stdint.h>

struct PhoneXRCompositor;

PhoneXRCompositor* phonexr_compositor_create(VkInstance instance, VkPhysicalDevice physicalDevice, VkDevice device, uint32_t queueFamily, uint32_t queueIndex, ANativeWindow* window);
void phonexr_compositor_destroy(PhoneXRCompositor* c);
bool phonexr_compositor_resize(PhoneXRCompositor* c, ANativeWindow* window);
bool phonexr_compositor_present(PhoneXRCompositor* c, VkImage source, VkExtent2D sourceExtent, VkImageLayout sourceLayout);
