#include <vulkan/vulkan.h>
#include <android/log.h>
#include <cstring>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "PhoneXR", __VA_ARGS__)

extern "C" void phonexr_probe_adreno(VkPhysicalDevice physicalDevice) {
    if (!physicalDevice) return;
    VkPhysicalDeviceProperties p{};
    vkGetPhysicalDeviceProperties(physicalDevice, &p);
    LOGI("GPU: %s vendor=0x%04x device=0x%04x driver=0x%x api=%u.%u.%u",
         p.deviceName, p.vendorID, p.deviceID, p.driverVersion,
         VK_VERSION_MAJOR(p.apiVersion), VK_VERSION_MINOR(p.apiVersion), VK_VERSION_PATCH(p.apiVersion));

    uint32_t n = 0;
    if (vkEnumerateDeviceExtensionProperties(physicalDevice, nullptr, &n, nullptr) != VK_SUCCESS) return;
    VkExtensionProperties* e = new VkExtensionProperties[n];
    if (vkEnumerateDeviceExtensionProperties(physicalDevice, nullptr, &n, e) == VK_SUCCESS) {
        bool qcomTile = false, qcomRenderPassTransform = false, extMesh = false;
        for (uint32_t i = 0; i < n; ++i) {
            qcomTile |= std::strcmp(e[i].extensionName, "VK_QCOM_tile_memory_heap") == 0;
            qcomRenderPassTransform |= std::strcmp(e[i].extensionName, "VK_QCOM_render_pass_transform") == 0;
            extMesh |= std::strcmp(e[i].extensionName, "VK_EXT_mesh_shader") == 0;
        }
        LOGI("Adreno capabilities: QCOM_tile_memory_heap=%d QCOM_render_pass_transform=%d EXT_mesh_shader=%d",
             qcomTile, qcomRenderPassTransform, extMesh);
    }
    delete[] e;
}
