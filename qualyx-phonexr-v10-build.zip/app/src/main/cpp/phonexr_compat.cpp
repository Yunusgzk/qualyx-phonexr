#include "openxr/phonexr_openxr_min.h"
#include <android/log.h>
#include <unordered_map>
#include <mutex>
#include <string>
#include <cstring>
#include <chrono>
struct XrSpace_T { int kind; };

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,"PhoneXR",__VA_ARGS__)
extern "C" void phonexr_probe_adreno(VkPhysicalDevice physicalDevice);

struct XrActionSet_T { std::string name; uint32_t priority=0; };
struct XrAction_T { std::string name; int type=0; };

static std::mutex g_action_mu;
static std::unordered_map<XrPath,std::string> g_paths;
static std::unordered_map<std::string,XrPath> g_path_ids;
static XrPath g_next_path=1;

static XrPath path_for(const char* s){
    if(!s) return 0;
    std::lock_guard<std::mutex> l(g_action_mu);
    auto it=g_path_ids.find(s); if(it!=g_path_ids.end()) return it->second;
    XrPath p=g_next_path++; g_path_ids[s]=p; g_paths[p]=s; return p;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrStringToPath(XrInstance i,const char* s,XrPath* p){
    if(!i||!s||!p) return XR_ERROR_VALIDATION_FAILURE; *p=path_for(s); return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrPathToString(XrInstance i,XrPath p,uint32_t cap,uint32_t* count,char* buf){
    if(!i||!count||!p) return XR_ERROR_VALIDATION_FAILURE;
    std::lock_guard<std::mutex> l(g_action_mu); auto it=g_paths.find(p); if(it==g_paths.end()) return XR_ERROR_PATH_INVALID;
    uint32_t need=(uint32_t)it->second.size()+1; *count=need;
    if(!buf) return XR_SUCCESS; if(cap<need) return XR_ERROR_SIZE_INSUFFICIENT; memcpy(buf,it->second.c_str(),need); return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrCreateActionSet(XrInstance i,const XrActionSetCreateInfo* ci,XrActionSet* out){
    if(!i||!ci||!out) return XR_ERROR_VALIDATION_FAILURE; auto* a=new XrActionSet_T; a->name=ci->actionSetName; a->priority=ci->priority; *out=a; return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrDestroyActionSet(XrActionSet a){delete a;return XR_SUCCESS;}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrCreateAction(XrActionSet set,const XrActionCreateInfo* ci,XrAction* out){
    if(!set||!ci||!out) return XR_ERROR_VALIDATION_FAILURE; auto* a=new XrAction_T; a->name=ci->actionName; a->type=ci->actionType; *out=a; return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrDestroyAction(XrAction a){delete a;return XR_SUCCESS;}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrAttachSessionActionSets(XrSession s,const XrSessionActionSetsAttachInfo* ci){return (s&&ci)?XR_SUCCESS:XR_ERROR_VALIDATION_FAILURE;}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrCreateActionSpace(XrSession s,const XrActionSpaceCreateInfo* ci,XrSpace* out){
    if(!s||!ci||!out) return XR_ERROR_VALIDATION_FAILURE; *out=(XrSpace)new XrSpace_T{2}; return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrSuggestInteractionProfileBindings(XrInstance i,const XrInteractionProfileSuggestedBinding* b){return (i&&b)?XR_SUCCESS:XR_ERROR_VALIDATION_FAILURE;}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrSyncActions(XrSession s,const XrActionsSyncInfo* info){return (s&&info)?XR_SUCCESS:XR_ERROR_VALIDATION_FAILURE;}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrGetActionStateBoolean(XrSession s,const XrActionStateGetInfo* gi,XrActionStateBoolean* st){
    if(!s||!gi||!st) return XR_ERROR_VALIDATION_FAILURE; st->currentState=0; st->changedSinceLastSync=0; st->lastChangeTime=0; st->isActive=1; return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrGetActionStateFloat(XrSession s,const XrActionStateGetInfo* gi,XrActionStateFloat* st){
    if(!s||!gi||!st) return XR_ERROR_VALIDATION_FAILURE; st->currentState=0.0f; st->changedSinceLastSync=0; st->lastChangeTime=0; st->isActive=1; return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrGetActionStateVector2f(XrSession s,const XrActionStateGetInfo* gi,XrActionStateVector2f* st){
    if(!s||!gi||!st) return XR_ERROR_VALIDATION_FAILURE; st->currentState={0,0}; st->changedSinceLastSync=0; st->lastChangeTime=0; st->isActive=1; return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrGetActionStatePose(XrSession s,const XrActionStateGetInfo* gi,XrActionStatePose* st){
    if(!s||!gi||!st) return XR_ERROR_VALIDATION_FAILURE; st->isActive=1; return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrStopHapticFeedback(XrSession s,const XrHapticActionInfo* h){return (s&&h)?XR_SUCCESS:XR_ERROR_VALIDATION_FAILURE;}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrApplyHapticFeedback(XrSession s,const XrHapticActionInfo* h,const void* vibration){return (s&&h&&vibration)?XR_SUCCESS:XR_ERROR_VALIDATION_FAILURE;}

struct XrInteractionProfileStateCompat { int type; void* next; XrPath interactionProfile; };
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrGetCurrentInteractionProfile(XrSession s,XrPath subactionPath,XrInteractionProfileStateCompat* st){
    if(!s||!st) return XR_ERROR_VALIDATION_FAILURE; st->interactionProfile=path_for("/interaction_profiles/khr/simple_controller"); return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrSetAndroidApplicationThreadKHR(XrSession s,uint32_t threadId,uint32_t threadType){
    if(!s) return XR_ERROR_HANDLE_INVALID; LOGI("Android thread hint: tid=%u type=%u",threadId,threadType); return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrPerfSettingsSetPerformanceLevelEXT(XrSession s,uint32_t domain,uint32_t level){
    return s?XR_SUCCESS:XR_ERROR_HANDLE_INVALID;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrEnumerateDisplayRefreshRatesFB(XrSession s,uint32_t cap,uint32_t* count,float* rates){
    if(!s||!count) return XR_ERROR_VALIDATION_FAILURE; const float r[]={60.0f,90.0f,120.0f}; *count=3; if(!rates) return XR_SUCCESS; if(cap<3) return XR_ERROR_SIZE_INSUFFICIENT; memcpy(rates,r,sizeof(r)); return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrGetDisplayRefreshRateFB(XrSession s,float* rate){if(!s||!rate)return XR_ERROR_VALIDATION_FAILURE;*rate=90.0f;return XR_SUCCESS;}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrRequestDisplayRefreshRateFB(XrSession s,float rate){return s?XR_SUCCESS:XR_ERROR_HANDLE_INVALID;}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrInitializeLoaderKHR(const void*){return XR_SUCCESS;}
