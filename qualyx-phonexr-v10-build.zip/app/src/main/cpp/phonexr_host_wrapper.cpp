#include <android_native_app_glue.h>
#include <android/log.h>
#include <dlfcn.h>
using MainFn=void(*)(android_app*);
extern "C" void phonexr_set_android_app(android_app*);
extern "C" void android_main(android_app* app){
    phonexr_set_android_app(app);
    void* rt=dlopen("libphonexr_runtime.so",RTLD_NOW|RTLD_GLOBAL);
    if(!rt){__android_log_print(ANDROID_LOG_WARN,"PhoneXR","runtime load failed: %s",dlerror());}
    void* h=dlopen("libhlvr_host_real.so",RTLD_NOW|RTLD_GLOBAL);
    if(!h){__android_log_print(ANDROID_LOG_ERROR,"PhoneXR","real host load failed: %s",dlerror());return;}
    auto fn=(MainFn)dlsym(h,"android_main");
    if(!fn){__android_log_print(ANDROID_LOG_ERROR,"PhoneXR","android_main not found");return;}
    fn(app);
}
