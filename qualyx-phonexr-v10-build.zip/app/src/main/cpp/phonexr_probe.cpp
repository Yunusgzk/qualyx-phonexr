#include "phonexr_window.h"
#include <android/log.h>
#include <android_native_app_glue.h>
#include <vulkan/vulkan.h>
#include <cstring>
#define L(...) __android_log_print(ANDROID_LOG_INFO,"PhoneXR",__VA_ARGS__)

static bool has_ext(const char* name, const VkExtensionProperties* e, uint32_t n){for(uint32_t i=0;i<n;i++) if(!strcmp(name,e[i].extensionName)) return true; return false;}

static void probe(android_app* app){
    phonexr_set_android_app(app);
    uint32_t n=0; VkResult r=vkEnumerateInstanceExtensionProperties(nullptr,&n,nullptr);
    L("Vulkan enumerate=%d extensions=%u",r,n);
    if(r!=VK_SUCCESS) return;
    VkExtensionProperties* e=new VkExtensionProperties[n]; vkEnumerateInstanceExtensionProperties(nullptr,&n,e);
    L("VK_KHR_surface=%d VK_KHR_android_surface=%d",has_ext("VK_KHR_surface",e,n),has_ext("VK_KHR_android_surface",e,n));
    uint32_t pdn=0; VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    const char* exts[]={"VK_KHR_surface","VK_KHR_android_surface"}; ci.enabledExtensionCount=2; ci.ppEnabledExtensionNames=exts;
    VkApplicationInfo ai{VK_STRUCTURE_TYPE_APPLICATION_INFO}; ai.pApplicationName="Qualyx PhoneXR Probe"; ai.apiVersion=VK_API_VERSION_1_1; ci.pApplicationInfo=&ai;
    VkInstance inst=VK_NULL_HANDLE; r=vkCreateInstance(&ci,nullptr,&inst); L("vkCreateInstance=%d",r);
    if(r==VK_SUCCESS){ vkEnumeratePhysicalDevices(inst,&pdn,nullptr); L("physical_devices=%u",pdn); if(pdn){VkPhysicalDevice pds[8]; if(pdn>8)pdn=8; vkEnumeratePhysicalDevices(inst,&pdn,pds); for(uint32_t i=0;i<pdn;i++){VkPhysicalDeviceProperties p{};vkGetPhysicalDeviceProperties(pds[i],&p);L("GPU[%u]: %s api=%u.%u.%u",i,p.deviceName,VK_VERSION_MAJOR(p.apiVersion),VK_VERSION_MINOR(p.apiVersion),VK_VERSION_PATCH(p.apiVersion));}} vkDestroyInstance(inst,nullptr);} delete[] e;
}
extern "C" void android_main(android_app* app){
    app_dummy();
    bool done=false; while(!done){ int ident,events; android_poll_source* source=nullptr; while((ident=ALooper_pollOnce(0,nullptr,&events,(void**)&source))>=0){ if(source) source->process(app,source); if(app->destroyRequested){done=true;break;} } if(app->window){ probe(app); break; } }
    while(!app->destroyRequested){ int ident,events; android_poll_source* source=nullptr; while((ident=ALooper_pollOnce(16,nullptr,&events,(void**)&source))>=0) if(source) source->process(app,source); }
}
