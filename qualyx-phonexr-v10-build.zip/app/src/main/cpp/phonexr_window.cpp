#include "phonexr_window.h"
#include <android/native_window.h>
#include <android_native_app_glue.h>
#include <android/log.h>
#include <mutex>
static std::mutex g_m;
static android_app* g_app=nullptr;
extern "C" void phonexr_set_android_app(android_app* app){ std::lock_guard<std::mutex> l(g_m); g_app=app; __android_log_print(ANDROID_LOG_INFO,"PhoneXR","android_app=%p",(void*)app); }
extern "C" ANativeWindow* phonexr_get_android_window(){ std::lock_guard<std::mutex> l(g_m); return g_app ? g_app->window : nullptr; }
