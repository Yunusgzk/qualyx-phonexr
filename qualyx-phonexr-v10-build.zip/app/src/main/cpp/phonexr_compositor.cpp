#include "phonexr_compositor.h"
#include <android/log.h>
#include <vector>
#include <cstring>
#include <algorithm>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,"PhoneXR",__VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,"PhoneXR",__VA_ARGS__)

struct PhoneXRCompositor {
    VkInstance instance=VK_NULL_HANDLE;
    VkPhysicalDevice physicalDevice=VK_NULL_HANDLE;
    VkDevice device=VK_NULL_HANDLE;
    VkQueue queue=VK_NULL_HANDLE;
    uint32_t queueFamily=0;
    ANativeWindow* window=nullptr;
    VkSurfaceKHR surface=VK_NULL_HANDLE;
    VkSwapchainKHR swapchain=VK_NULL_HANDLE;
    VkFormat format=VK_FORMAT_UNDEFINED;
    VkColorSpaceKHR colorSpace=VK_COLOR_SPACE_SRGB_NONLINEAR_KHR;
    VkExtent2D extent{};
    std::vector<VkImage> images;
    std::vector<VkImageView> views;
    VkCommandPool commandPool=VK_NULL_HANDLE;
    VkCommandBuffer commandBuffer=VK_NULL_HANDLE;
    VkSemaphore acquireSemaphore=VK_NULL_HANDLE;
    VkSemaphore presentSemaphore=VK_NULL_HANDLE;
    VkFence fence=VK_NULL_HANDLE;
    bool initialized=false;
};

static bool has_device_ext(VkPhysicalDevice pd,const char* name){
    uint32_t n=0; if(vkEnumerateDeviceExtensionProperties(pd,nullptr,&n,nullptr)!=VK_SUCCESS) return false;
    std::vector<VkExtensionProperties> e(n); if(n && vkEnumerateDeviceExtensionProperties(pd,nullptr,&n,e.data())!=VK_SUCCESS) return false;
    for(auto &x:e) if(!strcmp(x.extensionName,name)) return true; return false;
}
static uint32_t clamp_dim(uint32_t v,uint32_t lo,uint32_t hi){return std::max(lo,std::min(v,hi));}

static void cleanup_swapchain(PhoneXRCompositor* c){
    if(!c) return;
    if(c->device) vkDeviceWaitIdle(c->device);
    for(auto v:c->views) if(v) vkDestroyImageView(c->device,v,nullptr);
    c->views.clear(); c->images.clear();
    if(c->swapchain) vkDestroySwapchainKHR(c->device,c->swapchain,nullptr);
    c->swapchain=VK_NULL_HANDLE;
}

static bool create_surface(PhoneXRCompositor* c){
    if(c->surface || !c->window) return c->surface!=VK_NULL_HANDLE;
    auto f=(PFN_vkCreateAndroidSurfaceKHR)vkGetInstanceProcAddr(c->instance,"vkCreateAndroidSurfaceKHR");
    if(!f){LOGE("vkCreateAndroidSurfaceKHR unavailable; host Vulkan instance lacks Android surface extension");return false;}
    VkAndroidSurfaceCreateInfoKHR ci{VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR};
    ci.window=c->window;
    VkResult r=f(c->instance,&ci,nullptr,&c->surface);
    if(r!=VK_SUCCESS){LOGE("vkCreateAndroidSurfaceKHR=%d",r);c->surface=VK_NULL_HANDLE;return false;}
    return true;
}

static bool create_swapchain(PhoneXRCompositor* c){
    if(!c->surface) return false;
    auto getSupport=(PFN_vkGetPhysicalDeviceSurfaceSupportKHR)vkGetInstanceProcAddr(c->instance,"vkGetPhysicalDeviceSurfaceSupportKHR");
    auto getCaps=(PFN_vkGetPhysicalDeviceSurfaceCapabilitiesKHR)vkGetInstanceProcAddr(c->instance,"vkGetPhysicalDeviceSurfaceCapabilitiesKHR");
    auto getFormats=(PFN_vkGetPhysicalDeviceSurfaceFormatsKHR)vkGetInstanceProcAddr(c->instance,"vkGetPhysicalDeviceSurfaceFormatsKHR");
    if(!getSupport||!getCaps||!getFormats) return false;
    VkBool32 supported=VK_FALSE; if(getSupport(c->physicalDevice,c->queueFamily,c->surface,&supported)!=VK_SUCCESS||!supported){LOGE("queue family cannot present to Android surface");return false;}
    VkSurfaceCapabilitiesKHR caps{}; if(getCaps(c->physicalDevice,c->surface,&caps)!=VK_SUCCESS) return false;
    uint32_t nf=0; if(getFormats(c->physicalDevice,c->surface,&nf,nullptr)!=VK_SUCCESS||!nf) return false;
    std::vector<VkSurfaceFormatKHR> fmts(nf); getFormats(c->physicalDevice,c->surface,&nf,fmts.data());
    VkSurfaceFormatKHR chosen=fmts[0];
    for(auto f:fmts) if(f.format==VK_FORMAT_R8G8B8A8_SRGB && f.colorSpace==VK_COLOR_SPACE_SRGB_NONLINEAR_KHR){chosen=f;break;}
    VkExtent2D e=caps.currentExtent;
    if(e.width==UINT32_MAX){uint32_t w=std::max(1,ANativeWindow_getWidth(c->window));uint32_t h=std::max(1,ANativeWindow_getHeight(c->window));e.width=clamp_dim(w,caps.minImageExtent.width,caps.maxImageExtent.width);e.height=clamp_dim(h,caps.minImageExtent.height,caps.maxImageExtent.height);}
    uint32_t count=std::max(caps.minImageCount+1,3u); if(caps.maxImageCount && count>caps.maxImageCount) count=caps.maxImageCount;
    VkSwapchainCreateInfoKHR ci{VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR};
    ci.surface=c->surface; ci.minImageCount=count; ci.imageFormat=chosen.format; ci.imageColorSpace=chosen.colorSpace; ci.imageExtent=e; ci.imageArrayLayers=1; ci.imageUsage=VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT|VK_IMAGE_USAGE_TRANSFER_DST_BIT; ci.imageSharingMode=VK_SHARING_MODE_EXCLUSIVE; ci.preTransform=caps.currentTransform; ci.compositeAlpha=VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR; ci.presentMode=VK_PRESENT_MODE_FIFO_KHR; ci.clipped=VK_TRUE; ci.oldSwapchain=VK_NULL_HANDLE;
    VkResult r=vkCreateSwapchainKHR(c->device,&ci,nullptr,&c->swapchain); if(r!=VK_SUCCESS){LOGE("vkCreateSwapchainKHR=%d",r);return false;}
    uint32_t ni=0; vkGetSwapchainImagesKHR(c->device,c->swapchain,&ni,nullptr); c->images.resize(ni); vkGetSwapchainImagesKHR(c->device,c->swapchain,&ni,c->images.data());
    c->views.resize(ni);
    for(uint32_t i=0;i<ni;i++){VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};vi.image=c->images[i];vi.viewType=VK_IMAGE_VIEW_TYPE_2D;vi.format=chosen.format;vi.subresourceRange.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT;vi.subresourceRange.levelCount=1;vi.subresourceRange.layerCount=1;if(vkCreateImageView(c->device,&vi,nullptr,&c->views[i])!=VK_SUCCESS){cleanup_swapchain(c);return false;}}
    c->format=chosen.format;c->colorSpace=chosen.colorSpace;c->extent=e;c->initialized=true;
    LOGI("Android compositor: %ux%u format=%d images=%u",e.width,e.height,(int)chosen.format,ni); return true;
}

PhoneXRCompositor* phonexr_compositor_create(VkInstance instance,VkPhysicalDevice pd,VkDevice device,uint32_t qf,uint32_t qi,ANativeWindow* window){
    if(!instance||!pd||!device||!window) return nullptr;
    if(!has_device_ext(pd,"VK_KHR_swapchain")){LOGE("VK_KHR_swapchain missing");return nullptr;}
    auto* c=new PhoneXRCompositor; c->instance=instance;c->physicalDevice=pd;c->device=device;c->queueFamily=qf;c->window=window;
    vkGetDeviceQueue(device,qf,qi,&c->queue);
    if(!create_surface(c)||!create_swapchain(c)){phonexr_compositor_destroy(c);return nullptr;}
    VkCommandPoolCreateInfo pi{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};pi.queueFamilyIndex=qf;pi.flags=VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;if(vkCreateCommandPool(device,&pi,nullptr,&c->commandPool)!=VK_SUCCESS){phonexr_compositor_destroy(c);return nullptr;}
    VkCommandBufferAllocateInfo ai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};ai.commandPool=c->commandPool;ai.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;ai.commandBufferCount=1;if(vkAllocateCommandBuffers(device,&ai,&c->commandBuffer)!=VK_SUCCESS){phonexr_compositor_destroy(c);return nullptr;}
    VkSemaphoreCreateInfo si{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};if(vkCreateSemaphore(device,&si,nullptr,&c->acquireSemaphore)!=VK_SUCCESS||vkCreateSemaphore(device,&si,nullptr,&c->presentSemaphore)!=VK_SUCCESS){phonexr_compositor_destroy(c);return nullptr;}
    VkFenceCreateInfo fi{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};if(vkCreateFence(device,&fi,nullptr,&c->fence)!=VK_SUCCESS){phonexr_compositor_destroy(c);return nullptr;}
    return c;
}

void phonexr_compositor_destroy(PhoneXRCompositor* c){if(!c)return;if(c->device)vkDeviceWaitIdle(c->device);if(c->fence)vkDestroyFence(c->device,c->fence,nullptr);if(c->presentSemaphore)vkDestroySemaphore(c->device,c->presentSemaphore,nullptr);if(c->acquireSemaphore)vkDestroySemaphore(c->device,c->acquireSemaphore,nullptr);if(c->commandPool)vkDestroyCommandPool(c->device,c->commandPool,nullptr);cleanup_swapchain(c);if(c->surface&&c->instance){auto f=(PFN_vkDestroySurfaceKHR)vkGetInstanceProcAddr(c->instance,"vkDestroySurfaceKHR");if(f)f(c->instance,c->surface,nullptr);}delete c;}

bool phonexr_compositor_resize(PhoneXRCompositor* c,ANativeWindow* window){if(!c||!window)return false;if(window!=c->window){if(c->device)vkDeviceWaitIdle(c->device);c->window=window;}cleanup_swapchain(c);return create_swapchain(c);}

bool phonexr_compositor_present(PhoneXRCompositor* c,VkImage source,VkExtent2D sourceExtent,VkImageLayout sourceLayout){
    if(!c||!c->initialized||!source)return false;
    vkWaitForFences(c->device,1,&c->fence,VK_TRUE,UINT64_MAX);vkResetFences(c->device,1,&c->fence);
    uint32_t idx=0;VkResult r=vkAcquireNextImageKHR(c->device,c->swapchain,UINT64_MAX,c->acquireSemaphore,VK_NULL_HANDLE,&idx);if(r==VK_ERROR_OUT_OF_DATE_KHR){phonexr_compositor_resize(c,c->window);return false;}if(r!=VK_SUCCESS&&r!=VK_SUBOPTIMAL_KHR)return false;
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};bi.flags=VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;if(vkBeginCommandBuffer(c->commandBuffer,&bi)!=VK_SUCCESS)return false;
    VkImageMemoryBarrier2 src{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2};src.srcStageMask=VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;src.srcAccessMask=VK_ACCESS_2_MEMORY_WRITE_BIT;src.dstStageMask=VK_PIPELINE_STAGE_2_TRANSFER_BIT;src.dstAccessMask=VK_ACCESS_2_TRANSFER_READ_BIT;src.oldLayout=sourceLayout;src.newLayout=VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;src.image=source;src.subresourceRange.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT;src.subresourceRange.levelCount=1;src.subresourceRange.layerCount=1;
    VkImageMemoryBarrier2 dst{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2};dst.srcStageMask=VK_PIPELINE_STAGE_2_NONE;dst.srcAccessMask=0;dst.dstStageMask=VK_PIPELINE_STAGE_2_TRANSFER_BIT;dst.dstAccessMask=VK_ACCESS_2_TRANSFER_WRITE_BIT;dst.oldLayout=VK_IMAGE_LAYOUT_UNDEFINED;dst.newLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;dst.image=c->images[idx];dst.subresourceRange.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT;dst.subresourceRange.levelCount=1;dst.subresourceRange.layerCount=1;
    VkImageMemoryBarrier2 barriers[2]={src,dst};VkDependencyInfo dep{VK_STRUCTURE_TYPE_DEPENDENCY_INFO};dep.imageMemoryBarrierCount=2;dep.pImageMemoryBarriers=barriers;
    auto cmdPipelineBarrier2=(PFN_vkCmdPipelineBarrier2)vkGetDeviceProcAddr(c->device,"vkCmdPipelineBarrier2");
    if(cmdPipelineBarrier2) cmdPipelineBarrier2(c->commandBuffer,&dep); else {vkEndCommandBuffer(c->commandBuffer);return false;}
    VkImageBlit blit{};blit.srcSubresource.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT;blit.srcSubresource.layerCount=1;blit.srcOffsets[1]={(int32_t)sourceExtent.width,(int32_t)sourceExtent.height,1};blit.dstSubresource.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT;blit.dstSubresource.layerCount=1;blit.dstOffsets[1]={(int32_t)c->extent.width,(int32_t)c->extent.height,1};
    vkCmdBlitImage(c->commandBuffer,source,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,c->images[idx],VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,&blit,VK_FILTER_LINEAR);
    VkImageMemoryBarrier2 dst2{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2};dst2.srcStageMask=VK_PIPELINE_STAGE_2_TRANSFER_BIT;dst2.srcAccessMask=VK_ACCESS_2_TRANSFER_WRITE_BIT;dst2.dstStageMask=VK_PIPELINE_STAGE_2_BOTTOM_OF_PIPE_BIT;dst2.dstAccessMask=0;dst2.oldLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;dst2.newLayout=VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;dst2.image=c->images[idx];dst2.subresourceRange.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT;dst2.subresourceRange.levelCount=1;dst2.subresourceRange.layerCount=1;
    dep.imageMemoryBarrierCount=1;dep.pImageMemoryBarriers=&dst2;cmdPipelineBarrier2(c->commandBuffer,&dep);if(vkEndCommandBuffer(c->commandBuffer)!=VK_SUCCESS)return false;
    VkPipelineStageFlags waitStage=VK_PIPELINE_STAGE_TRANSFER_BIT;VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};si.waitSemaphoreCount=1;si.pWaitSemaphores=&c->acquireSemaphore;si.pWaitDstStageMask=&waitStage;si.commandBufferCount=1;si.pCommandBuffers=&c->commandBuffer;si.signalSemaphoreCount=1;si.pSignalSemaphores=&c->presentSemaphore;if(vkQueueSubmit(c->queue,1,&si,c->fence)!=VK_SUCCESS)return false;
    VkPresentInfoKHR pi{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR};pi.waitSemaphoreCount=1;pi.pWaitSemaphores=&c->presentSemaphore;pi.swapchainCount=1;pi.pSwapchains=&c->swapchain;pi.pImageIndices=&idx;r=vkQueuePresentKHR(c->queue,&pi);if(r==VK_ERROR_OUT_OF_DATE_KHR||r==VK_SUBOPTIMAL_KHR) phonexr_compositor_resize(c,c->window);return r==VK_SUCCESS||r==VK_SUBOPTIMAL_KHR;
}
