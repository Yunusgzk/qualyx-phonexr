#include "openxr/phonexr_openxr_min.h"
#include <android/log.h>
#include <vulkan/vulkan.h>
#include <string.h>
#include <chrono>
#include <mutex>
#include <vector>
#include <atomic>
#include <algorithm>
#include <stdint.h>
#include "phonexr_window.h"
#include "phonexr_compositor.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,"PhoneXR",__VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,"PhoneXR",__VA_ARGS__)

// PhoneXR v0.7: real Vulkan session/swapchain bridge.
// The runtime does not fabricate VkImage handles. It consumes the application's
// Vulkan graphics binding and creates/binds real images on the supplied device.

struct XrInstance_T { uint64_t magic=0x5058524953544e43ULL; };
struct SwapImage { VkImage image=VK_NULL_HANDLE; VkDeviceMemory memory=VK_NULL_HANDLE; };
struct XrSwapchain_T;
struct XrSession_T { XrInstance inst=nullptr; bool running=false; VkInstance vkInstance=VK_NULL_HANDLE; VkPhysicalDevice physicalDevice=VK_NULL_HANDLE; VkDevice device=VK_NULL_HANDLE; uint32_t queueFamilyIndex=0; uint32_t queueIndex=0; bool readyEventPending=true; std::vector<XrSwapchain> swapchains; PhoneXRCompositor* compositor=nullptr; };
struct XrSpace_T { int kind=0; };
struct XrSwapchain_T {
    XrSession session=nullptr;
    VkDevice device=VK_NULL_HANDLE;
    VkPhysicalDevice physicalDevice=VK_NULL_HANDLE;
    std::vector<SwapImage> images;
    uint32_t nextImage=0;
    bool acquired=false;
    std::mutex mu;
};

static XrInstance g_inst=nullptr;
static std::vector<XrSession> g_sessions;
static std::mutex g_mu;
static std::atomic<uint64_t> g_frame{0};

static uint64_t now_ns(){
    return (uint64_t)std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}
static bool nameeq(const char*a,const char*b){return a&&b&&!strcmp(a,b);}
static uint32_t u32max(uint32_t a,uint32_t b){return a>b?a:b;}

static const char* kVulkanEnable2 = "XR_KHR_vulkan_enable2";
static const char* kVulkanEnable  = "XR_KHR_vulkan_enable";

// Minimal layout of XrGraphicsBindingVulkan2KHR/VulkanKHR. The common prefix is
// identical for the fields we need: type, next, instance, physicalDevice, device,
// queueFamilyIndex, queueIndex.
struct VulkanBindingCommon {
    int type;
    const void* next;
    VkInstance instance;
    VkPhysicalDevice physicalDevice;
    VkDevice device;
    uint32_t queueFamilyIndex;
    uint32_t queueIndex;
};

static VkImageUsageFlags xr_usage_to_vk(XrFlags64 flags){
    VkImageUsageFlags u=0;
    if(flags & 0x1)  u |= VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    if(flags & 0x2)  u |= VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
    if(flags & 0x4)  u |= VK_IMAGE_USAGE_STORAGE_BIT;
    if(flags & 0x8)  u |= VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
    if(flags & 0x10) u |= VK_IMAGE_USAGE_TRANSFER_DST_BIT;
    if(flags & 0x20) u |= VK_IMAGE_USAGE_SAMPLED_BIT;
    return u;
}

static uint32_t find_memory_type(VkPhysicalDevice pd, uint32_t typeBits, VkMemoryPropertyFlags wanted){
    VkPhysicalDeviceMemoryProperties mp{};
    vkGetPhysicalDeviceMemoryProperties(pd,&mp);
    for(uint32_t i=0;i<mp.memoryTypeCount;i++)
        if((typeBits&(1u<<i)) && (mp.memoryTypes[i].propertyFlags&wanted)==wanted) return i;
    return UINT32_MAX;
}

static void destroy_swapchain_images(XrSwapchain sc){
    if(!sc || !sc->device) return;
    for(auto &im:sc->images){
        if(im.image) vkDestroyImage(sc->device,im.image,nullptr);
        if(im.memory) vkFreeMemory(sc->device,im.memory,nullptr);
        im.image=VK_NULL_HANDLE; im.memory=VK_NULL_HANDLE;
    }
    sc->images.clear();
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrEnumerateInstanceExtensionProperties(const char*, uint32_t capacity, uint32_t* count, void* properties){
    if(!count) return XR_ERROR_VALIDATION_FAILURE;
    const char* names[]={kVulkanEnable2,kVulkanEnable,"XR_KHR_android_thread_settings","XR_EXT_performance_settings","XR_FB_display_refresh_rate"};
    constexpr uint32_t N=5;
    *count=N;
    if(!properties) return XR_SUCCESS;
    if(capacity<N) return XR_ERROR_SIZE_INSUFFICIENT;
    struct Ext { int type; void* next; char extensionName[128]; uint32_t extensionVersion; };
    auto* p=(Ext*)properties;
    memset(p,0,sizeof(Ext)*N);
    for(uint32_t n=0;n<N;n++){ p[n].type=2; strncpy(p[n].extensionName,names[n],sizeof(p[n].extensionName)-1); p[n].extensionVersion=1; }
    p[0].extensionVersion=2;
    return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrCreateInstance(const XrInstanceCreateInfo* ci,XrInstance* out){
    if(!out) return XR_ERROR_VALIDATION_FAILURE;
    std::lock_guard<std::mutex> l(g_mu);
    if(g_inst) return XR_ERROR_RUNTIME_FAILURE;
    g_inst=new XrInstance_T;
    *out=g_inst;
    LOGI("xrCreateInstance: PhoneXR v0.7");
    if(ci) LOGI("app=%s api=%llu",ci->applicationInfo.applicationName,(unsigned long long)ci->applicationInfo.apiVersion);
    return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrDestroyInstance(XrInstance i){
    std::lock_guard<std::mutex> l(g_mu);
    if(i!=g_inst) return XR_ERROR_HANDLE_INVALID;
    if(!g_sessions.empty()) return XR_ERROR_RUNTIME_FAILURE;
    delete g_inst; g_inst=nullptr; return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrGetSystem(XrInstance i,const XrSystemGetInfo* gi,XrSystemId* id){
    if(i!=g_inst||!id||!gi) return XR_ERROR_VALIDATION_FAILURE;
    if(gi->formFactor!=XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY) return XR_ERROR_FORM_FACTOR_UNSUPPORTED;
    *id=1; return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrGetSystemProperties(XrInstance i,XrSystemId id,void* props){
    if(i!=g_inst||id!=1||!props) return XR_ERROR_HANDLE_INVALID;
    auto* p=(XrSystemProperties*)props;
    p->type=5; p->next=nullptr; p->systemId=1; p->vendorId=0x5158;
    strncpy(p->systemName,"PhoneXR Android Vulkan",sizeof(p->systemName)-1);
    p->graphicsProperties.maxSwapchainImageWidth=3840;
    p->graphicsProperties.maxSwapchainImageHeight=3840;
    p->graphicsProperties.maxLayerCount=4;
    p->trackingProperties.orientationTracking=1;
    p->trackingProperties.positionTracking=0;
    return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrCreateSession(XrInstance i,const XrSessionCreateInfo* ci,XrSession*out){
    if(i!=g_inst||!out||!ci) return XR_ERROR_VALIDATION_FAILURE;
    auto* s=new XrSession_T{i,false,VK_NULL_HANDLE,VK_NULL_HANDLE,VK_NULL_HANDLE,0,0,true,{}};
    if(ci->graphicsBinding){
        const auto* b=(const VulkanBindingCommon*)ci->graphicsBinding;
        if(b->instance && b->physicalDevice && b->device){
            s->vkInstance=b->instance; s->physicalDevice=b->physicalDevice; s->device=b->device;
            s->queueFamilyIndex=b->queueFamilyIndex; s->queueIndex=b->queueIndex;
            VkPhysicalDeviceProperties props{}; vkGetPhysicalDeviceProperties(s->physicalDevice,&props);
            LOGI("GPU: %s vendor=0x%x device=0x%x driver=%u api=%u.%u.%u", props.deviceName, props.vendorID, props.deviceID, props.driverVersion, VK_VERSION_MAJOR(props.apiVersion), VK_VERSION_MINOR(props.apiVersion), VK_VERSION_PATCH(props.apiVersion));
            uint32_t extCount=0; vkEnumerateDeviceExtensionProperties(s->physicalDevice,nullptr,&extCount,nullptr);
            std::vector<VkExtensionProperties> exts(extCount); if(extCount) vkEnumerateDeviceExtensionProperties(s->physicalDevice,nullptr,&extCount,exts.data());
            bool tile=false, mesh=false; for(auto &e:exts){ tile |= !strcmp(e.extensionName,"VK_QCOM_tile_memory_heap"); mesh |= !strcmp(e.extensionName,"VK_EXT_mesh_shader"); }
            LOGI("Adreno tuning: tile_memory=%d mesh_shader=%d image_count=3",tile?1:0,mesh?1:0);
            LOGI("xrCreateSession: Vulkan instance=%p physical=%p device=%p queue=%u/%u",
                 (void*)b->instance,(void*)b->physicalDevice,(void*)b->device,
                 b->queueFamilyIndex,b->queueIndex);
        } else {
            LOGE("xrCreateSession: incomplete Vulkan graphics binding");
        }
    } else {
        LOGE("xrCreateSession: no graphics binding");
    }
    if(s->device && s->physicalDevice && s->vkInstance){
        ANativeWindow* w=phonexr_get_android_window();
        if(w) s->compositor=phonexr_compositor_create(s->vkInstance,s->physicalDevice,s->device,s->queueFamilyIndex,s->queueIndex,w);
        if(!s->compositor) LOGI("Android compositor not active yet; waiting for a valid ANativeWindow/VK_KHR_swapchain");
    }
    { std::lock_guard<std::mutex> l(g_mu); g_sessions.push_back(s); }
    *out=s; return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrDestroySession(XrSession s){
    if(!s) return XR_ERROR_HANDLE_INVALID;
    std::lock_guard<std::mutex> l(g_mu);
    for(auto it=g_sessions.begin();it!=g_sessions.end();++it){
        if(*it==s){
            for(auto sc:s->swapchains){ destroy_swapchain_images(sc); delete sc; }
            if(s->compositor){ phonexr_compositor_destroy(s->compositor); s->compositor=nullptr; }
            s->swapchains.clear();
            g_sessions.erase(it); delete s; return XR_SUCCESS;
        }
    }
    return XR_ERROR_HANDLE_INVALID;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrBeginSession(XrSession s,const XrSessionBeginInfo* bi){ if(!s||!bi)return XR_ERROR_VALIDATION_FAILURE; s->running=true; return XR_SUCCESS; }
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrEndSession(XrSession s){ if(!s)return XR_ERROR_HANDLE_INVALID; s->running=false; return XR_SUCCESS; }
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrPollEvent(XrInstance i,void* eventData){
    if(i!=g_inst||!eventData) return XR_ERROR_HANDLE_INVALID;
    std::lock_guard<std::mutex> l(g_mu);
    for(auto* s:g_sessions){
        if(s && s->readyEventPending){
            auto* e=(XrEventDataSessionStateChanged*)eventData;
            e->type=XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED; e->next=nullptr;
            e->session=s; e->state=XR_SESSION_STATE_READY; e->time=now_ns();
            s->readyEventPending=false;
            LOGI("xrPollEvent: SESSION_STATE_READY");
            return XR_SUCCESS;
        }
    }
    return XR_EVENT_UNAVAILABLE;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrWaitFrame(XrSession s,const XrFrameWaitInfo*,XrFrameState* st){
    if(!s||!st) return XR_ERROR_VALIDATION_FAILURE;
    st->predictedDisplayTime=now_ns()+16666666;
    st->predictedDisplayPeriod=16666666;
    st->shouldRender=s->running?1:0;
    ++g_frame; return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrBeginFrame(XrSession s,const XrFrameBeginInfo*){return s?XR_SUCCESS:XR_ERROR_HANDLE_INVALID;}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrEndFrame(XrSession s,const XrFrameEndInfo* e){
    if(!s) return XR_ERROR_HANDLE_INVALID;
    if(e) {
        LOGI("frame=%llu layers=%u",(unsigned long long)g_frame.load(),e->layerCount);
        if(s->compositor && !s->swapchains.empty() && !s->swapchains[0]->images.empty()) {
            auto& sc=*s->swapchains[0];
            VkExtent2D ex{1,1};
            /* The first swapchain is the runtime render target. We currently present
               its first image as a conservative compatibility path; full projection
               layer rect/eye routing is the next compositor step. */
            ex.width=1920; ex.height=1080;
            phonexr_compositor_present(s->compositor,sc.images[0].image,ex,VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL);
        }
    }
    return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrEnumerateViewConfigurationViews(XrInstance i,XrSystemId id,int,uint32_t n,uint32_t*c,XrViewConfigurationView*v){
    if(i!=g_inst||id!=1||!c) return XR_ERROR_VALIDATION_FAILURE;
    *c=2;
    if(v&&n>=2){for(int k=0;k<2;k++){v[k].type=41;v[k].next=nullptr;v[k].recommendedImageRectWidth=1920;v[k].recommendedImageRectHeight=1080;v[k].maxImageRectWidth=3840;v[k].maxImageRectHeight=2160;v[k].recommendedSwapchainSampleCount=1;v[k].maxSwapchainSampleCount=1;}}
    return v&&n<2?XR_ERROR_SIZE_INSUFFICIENT:XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrLocateViews(XrSession s,const XrViewLocateInfo*,void*,uint32_t n,uint32_t*c,XrView*v){
    if(!s||!c) return XR_ERROR_VALIDATION_FAILURE;
    *c=2;
    if(v&&n>=2){for(int k=0;k<2;k++){v[k].type=7;v[k].next=nullptr;v[k].pose.orientation={0,0,0,1};v[k].pose.position={(k?0.032f:-0.032f),0,0};v[k].fov={-0.9f,0.9f,0.9f,-0.9f};}}
    return v&&n<2?XR_ERROR_SIZE_INSUFFICIENT:XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrCreateReferenceSpace(XrSession s,const XrReferenceSpaceCreateInfo*,XrSpace*out){if(!s||!out)return XR_ERROR_VALIDATION_FAILURE;*out=new XrSpace_T{1};return XR_SUCCESS;}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrDestroySpace(XrSpace s){delete s;return XR_SUCCESS;}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrLocateSpace(XrSpace a,XrSpace b,XrTime,void* loc){return(a&&b&&loc)?XR_SUCCESS:XR_ERROR_VALIDATION_FAILURE;}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrEnumerateSwapchainFormats(XrSession s,uint32_t capacity,uint32_t*count,int64_t*formats){
    if(!s||!count) return XR_ERROR_VALIDATION_FAILURE;
    const VkFormat candidates[]={VK_FORMAT_R8G8B8A8_SRGB,VK_FORMAT_R8G8B8A8_UNORM,VK_FORMAT_B8G8R8A8_SRGB,VK_FORMAT_B8G8R8A8_UNORM,VK_FORMAT_R16G16B16A16_SFLOAT};
    uint32_t n=0;
    for(VkFormat f:candidates){VkFormatProperties p{};vkGetPhysicalDeviceFormatProperties(s->physicalDevice,f,&p);if(p.optimalTilingFeatures&VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT)n++;}
    *count=n;
    if(!formats) return XR_SUCCESS;
    if(capacity<n) return XR_ERROR_SIZE_INSUFFICIENT;
    uint32_t w=0;
    for(VkFormat f:candidates){VkFormatProperties p{};vkGetPhysicalDeviceFormatProperties(s->physicalDevice,f,&p);if(p.optimalTilingFeatures&VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT)formats[w++]=(int64_t)f;}
    return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrCreateSwapchain(XrSession s,const XrSwapchainCreateInfo* ci,XrSwapchain*out){
    if(!s||!ci||!out) return XR_ERROR_VALIDATION_FAILURE;
    if(!s->device||!s->physicalDevice) return XR_ERROR_RUNTIME_FAILURE;
    if(!ci->width||!ci->height||ci->width>16384||ci->height>16384) return XR_ERROR_VALIDATION_FAILURE;

    VkFormat format=(VkFormat)ci->format;
    VkFormatProperties fp{};
    vkGetPhysicalDeviceFormatProperties(s->physicalDevice,format,&fp);
    if(!(fp.optimalTilingFeatures & (VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT|VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT|VK_FORMAT_FEATURE_TRANSFER_SRC_BIT|VK_FORMAT_FEATURE_TRANSFER_DST_BIT|VK_FORMAT_FEATURE_STORAGE_IMAGE_BIT))) {
        LOGE("xrCreateSwapchain: format %d unsupported for required image usage",(int)format);
        return XR_ERROR_RUNTIME_FAILURE;
    }

    VkImageUsageFlags usage=xr_usage_to_vk(ci->usageFlags);
    if(!usage) usage=VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    const uint32_t layers=u32max((uint32_t)ci->arraySize,1);
    const uint32_t mipLevels=u32max((uint32_t)ci->mipCount,1);
    VkSampleCountFlagBits samples=VK_SAMPLE_COUNT_1_BIT;
    if(ci->sampleCount==2) samples=VK_SAMPLE_COUNT_2_BIT;
    else if(ci->sampleCount==4) samples=VK_SAMPLE_COUNT_4_BIT;
    else if(ci->sampleCount==8) samples=VK_SAMPLE_COUNT_8_BIT;

    auto* sc=new XrSwapchain_T;
    sc->session=s; sc->device=s->device; sc->physicalDevice=s->physicalDevice;
    const uint32_t imageCount=3; // triple-buffered OpenXR image set
    sc->images.resize(imageCount);

    for(uint32_t n=0;n<imageCount;n++){
        VkImageCreateInfo ici{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
        ici.imageType=VK_IMAGE_TYPE_2D;
        ici.format=format;
        ici.extent={ (uint32_t)ci->width, (uint32_t)ci->height, 1 };
        ici.mipLevels=mipLevels;
        ici.arrayLayers=layers;
        ici.samples=samples;
        ici.tiling=VK_IMAGE_TILING_OPTIMAL;
        ici.usage=usage;
        ici.sharingMode=VK_SHARING_MODE_EXCLUSIVE;
        ici.initialLayout=VK_IMAGE_LAYOUT_UNDEFINED;
        VkResult r=vkCreateImage(sc->device,&ici,nullptr,&sc->images[n].image);
        if(r!=VK_SUCCESS){
            LOGE("xrCreateSwapchain: vkCreateImage[%u]=%d",n,r);
            destroy_swapchain_images(sc); delete sc; return XR_ERROR_RUNTIME_FAILURE;
        }
        VkMemoryRequirements mr{}; vkGetImageMemoryRequirements(sc->device,sc->images[n].image,&mr);
        uint32_t mt=find_memory_type(sc->physicalDevice,mr.memoryTypeBits,VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
        if(mt==UINT32_MAX) mt=find_memory_type(sc->physicalDevice,mr.memoryTypeBits,0);
        if(mt==UINT32_MAX){
            LOGE("xrCreateSwapchain: no compatible memory type");
            destroy_swapchain_images(sc); delete sc; return XR_ERROR_RUNTIME_FAILURE;
        }
        VkMemoryAllocateInfo mai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        mai.allocationSize=mr.size; mai.memoryTypeIndex=mt;
        r=vkAllocateMemory(sc->device,&mai,nullptr,&sc->images[n].memory);
        if(r!=VK_SUCCESS){
            LOGE("xrCreateSwapchain: vkAllocateMemory[%u]=%d",n,r);
            destroy_swapchain_images(sc); delete sc; return XR_ERROR_RUNTIME_FAILURE;
        }
        r=vkBindImageMemory(sc->device,sc->images[n].image,sc->images[n].memory,0);
        if(r!=VK_SUCCESS){
            LOGE("xrCreateSwapchain: vkBindImageMemory[%u]=%d",n,r);
            destroy_swapchain_images(sc); delete sc; return XR_ERROR_RUNTIME_FAILURE;
        }
    }

    {
        std::lock_guard<std::mutex> l(g_mu);
        s->swapchains.push_back(sc);
    }
    *out=sc;
    LOGI("xrCreateSwapchain: %ux%u layers=%u images=%u format=%d usage=0x%x",ci->width,ci->height,layers,imageCount,(int)format,(unsigned)usage);
    return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrDestroySwapchain(XrSwapchain s){
    if(!s) return XR_ERROR_HANDLE_INVALID;
    if(s->session){
        std::lock_guard<std::mutex> l(g_mu);
        auto &v=s->session->swapchains;
        v.erase(std::remove(v.begin(),v.end(),s),v.end());
    }
    destroy_swapchain_images(s); delete s; return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrEnumerateSwapchainImages(XrSwapchain s,uint32_t capacity,uint32_t*c,XrSwapchainImageBaseHeader*images){
    if(!s||!c) return XR_ERROR_VALIDATION_FAILURE;
    const uint32_t n=(uint32_t)s->images.size(); *c=n;
    if(!images) return XR_SUCCESS;
    if(capacity<n) return XR_ERROR_SIZE_INSUFFICIENT;
    auto* out=(XrSwapchainImageVulkanKHR*)images;
    for(uint32_t i=0;i<n;i++){
        out[i].type=XR_TYPE_SWAPCHAIN_IMAGE_VULKAN_KHR;
        out[i].next=nullptr;
        out[i].image=(uint64_t)s->images[i].image;
    }
    return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrAcquireSwapchainImage(XrSwapchain s,uint32_t*index,const void*){
    if(!s||!index) return XR_ERROR_VALIDATION_FAILURE;
    std::lock_guard<std::mutex> l(s->mu);
    if(s->acquired) return XR_ERROR_RUNTIME_FAILURE;
    *index=s->nextImage++ % (uint32_t)s->images.size();
    s->acquired=true;
    return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrWaitSwapchainImage(XrSwapchain s,const void*){
    if(!s) return XR_ERROR_HANDLE_INVALID;
    std::lock_guard<std::mutex> l(s->mu);
    return s->acquired?XR_SUCCESS:XR_ERROR_RUNTIME_FAILURE;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrReleaseSwapchainImage(XrSwapchain s,const void*){
    if(!s) return XR_ERROR_HANDLE_INVALID;
    std::lock_guard<std::mutex> l(s->mu);
    if(!s->acquired) return XR_ERROR_RUNTIME_FAILURE;
    s->acquired=false; return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrGetVulkanGraphicsRequirements2KHR(XrInstance i,XrSystemId s,XrGraphicsRequirementsVulkanKHR*r){
    if(i!=g_inst||s!=1||!r)return XR_ERROR_VALIDATION_FAILURE;
    r->minApiVersionSupported=VK_MAKE_API_VERSION(0,1,1,0);
    r->maxApiVersionSupported=VK_MAKE_API_VERSION(0,1,3,0);
    return XR_SUCCESS;
}
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrGetVulkanGraphicsRequirementsKHR(XrInstance i,XrSystemId s,XrGraphicsRequirementsVulkanKHR*r){return xrGetVulkanGraphicsRequirements2KHR(i,s,r);}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrGetVulkanGraphicsDevice2KHR(XrInstance i,XrVulkanGraphicsDeviceGetInfoKHR* info,VkPhysicalDevice*out){
    if(i!=g_inst||!info||!out)return XR_ERROR_VALIDATION_FAILURE;
    auto f=(PFN_vkEnumeratePhysicalDevices)vkGetInstanceProcAddr((VkInstance)info->vulkanInstance,"vkEnumeratePhysicalDevices");
    if(!f)return XR_ERROR_RUNTIME_FAILURE;
    uint32_t n=0; if(f((VkInstance)info->vulkanInstance,&n,nullptr)!=VK_SUCCESS||!n)return XR_ERROR_RUNTIME_FAILURE;
    VkPhysicalDevice d[8]{}; if(n>8)n=8; if(f((VkInstance)info->vulkanInstance,&n,d)!=VK_SUCCESS||!n)return XR_ERROR_RUNTIME_FAILURE;
    *out=d[0]; LOGI("Selected Vulkan physical device %p",(void*)*out); return XR_SUCCESS;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrCreateVulkanInstanceKHR(XrInstance i,const XrVulkanInstanceCreateInfoKHR* ci,VkResult* vkResult,VkInstance*out,const VkAllocationCallbacks* allocator){
    if(i!=g_inst||!ci||!out)return XR_ERROR_VALIDATION_FAILURE;
    auto f=(PFN_vkCreateInstance)ci->pfnGetInstanceProcAddr;
    if(!f) return XR_ERROR_RUNTIME_FAILURE;
    VkResult r=f((const VkInstanceCreateInfo*)ci->vulkanCreateInfo,allocator,out);
    if(vkResult)*vkResult=r; return r==VK_SUCCESS?XR_SUCCESS:XR_ERROR_RUNTIME_FAILURE;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrCreateVulkanDeviceKHR(XrInstance i,const XrVulkanDeviceCreateInfoKHR* ci,VkResult* vkResult,VkDevice*out,const VkAllocationCallbacks* allocator){
    if(i!=g_inst||!ci||!out)return XR_ERROR_VALIDATION_FAILURE;
    if(!ci->vulkanPhysicalDevice || !ci->vulkanCreateInfo) return XR_ERROR_VALIDATION_FAILURE;
    auto get=(PFN_vkGetInstanceProcAddr)ci->pfnGetInstanceProcAddr;
    if(!get) return XR_ERROR_RUNTIME_FAILURE;
    auto create=(PFN_vkCreateDevice)get(VK_NULL_HANDLE,"vkCreateDevice");
    if(!create){
        // Some loaders need the physical device's dispatch table rather than a
        // null instance. Resolve through the global loader as a fallback.
        create=(PFN_vkCreateDevice)vkGetInstanceProcAddr(VK_NULL_HANDLE,"vkCreateDevice");
    }
    if(!create) return XR_ERROR_RUNTIME_FAILURE;
    VkResult r=create((VkPhysicalDevice)ci->vulkanPhysicalDevice,(const VkDeviceCreateInfo*)ci->vulkanCreateInfo,allocator,out);
    if(vkResult)*vkResult=r;
    LOGI("xrCreateVulkanDeviceKHR: vkCreateDevice=%d device=%p",r,out?(void*)*out:nullptr);
    return r==VK_SUCCESS?XR_SUCCESS:XR_ERROR_RUNTIME_FAILURE;
}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrGetInstanceProperties(XrInstance i,void*){return i==g_inst?XR_SUCCESS:XR_ERROR_HANDLE_INVALID;}

extern "C" XRAPI_ATTR XrResult XRAPI_CALL
xrGetInstanceProcAddr(XrInstance i,const char* name,PFN_xrVoidFunction*out){
    if(!out||!name)return XR_ERROR_VALIDATION_FAILURE;
#define MAP(x) if(nameeq(name,#x)){*out=(PFN_xrVoidFunction)x;return XR_SUCCESS;}
    MAP(xrGetInstanceProcAddr) MAP(xrCreateInstance) MAP(xrDestroyInstance) MAP(xrGetSystem)
    MAP(xrGetSystemProperties) MAP(xrCreateSession) MAP(xrEnumerateSwapchainFormats) MAP(xrDestroySession) MAP(xrBeginSession)
    MAP(xrEndSession) MAP(xrPollEvent) MAP(xrWaitFrame) MAP(xrBeginFrame) MAP(xrEndFrame)
    MAP(xrEnumerateViewConfigurationViews) MAP(xrLocateViews) MAP(xrCreateReferenceSpace)
    MAP(xrDestroySpace) MAP(xrLocateSpace) MAP(xrCreateSwapchain) MAP(xrDestroySwapchain)
    MAP(xrEnumerateSwapchainImages) MAP(xrAcquireSwapchainImage) MAP(xrWaitSwapchainImage)
    MAP(xrReleaseSwapchainImage) MAP(xrStringToPath) MAP(xrPathToString)
    MAP(xrCreateActionSet) MAP(xrDestroyActionSet) MAP(xrCreateAction) MAP(xrDestroyAction)
    MAP(xrAttachSessionActionSets) MAP(xrCreateActionSpace) MAP(xrSuggestInteractionProfileBindings) MAP(xrSyncActions)
    MAP(xrGetActionStateBoolean) MAP(xrGetActionStateFloat) MAP(xrGetActionStateVector2f) MAP(xrGetActionStatePose)
    MAP(xrStopHapticFeedback) MAP(xrApplyHapticFeedback) MAP(xrGetCurrentInteractionProfile)
    MAP(xrSetAndroidApplicationThreadKHR) MAP(xrPerfSettingsSetPerformanceLevelEXT)
    MAP(xrEnumerateDisplayRefreshRatesFB) MAP(xrGetDisplayRefreshRateFB) MAP(xrRequestDisplayRefreshRateFB) MAP(xrInitializeLoaderKHR)
    MAP(xrGetVulkanGraphicsRequirements2KHR)
    MAP(xrGetVulkanGraphicsRequirementsKHR) MAP(xrGetVulkanGraphicsDevice2KHR)
    MAP(xrCreateVulkanInstanceKHR) MAP(xrCreateVulkanDeviceKHR) MAP(xrGetInstanceProperties)
#undef MAP
    *out=nullptr; return XR_ERROR_FUNCTION_UNSUPPORTED;
}
