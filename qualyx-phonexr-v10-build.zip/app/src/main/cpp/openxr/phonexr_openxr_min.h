#pragma once
#include <stdint.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef int32_t XrResult;
typedef uint32_t XrBool32;
typedef uint64_t XrFlags64, XrSystemId, XrVersion, XrPath;
typedef struct XrInstance_T* XrInstance;
typedef struct XrSession_T* XrSession;
typedef struct XrSpace_T* XrSpace;
typedef struct XrActionSet_T* XrActionSet;
typedef struct XrAction_T* XrAction;
typedef struct XrSwapchain_T* XrSwapchain;
typedef uint64_t XrTime;
typedef int64_t XrDuration;

enum { XR_SUCCESS=0, XR_TIMEOUT_EXPIRED=1, XR_EVENT_UNAVAILABLE=4, XR_ERROR_VALIDATION_FAILURE=-1, XR_ERROR_RUNTIME_FAILURE=-2, XR_ERROR_HANDLE_INVALID=-12, XR_ERROR_SIZE_INSUFFICIENT=-11, XR_ERROR_FUNCTION_UNSUPPORTED=-7, XR_ERROR_FORM_FACTOR_UNSUPPORTED=-8, XR_ERROR_SYSTEM_INVALID=-13, XR_ERROR_PATH_INVALID=-17, XR_ERROR_ACTION_TYPE_MISMATCH=-27 };
enum { XR_TYPE_UNKNOWN=0, XR_TYPE_INSTANCE_CREATE_INFO=3, XR_TYPE_SYSTEM_GET_INFO=4, XR_TYPE_SESSION_CREATE_INFO=8, XR_TYPE_REFERENCE_SPACE_CREATE_INFO=37, XR_TYPE_VIEW_LOCATE_INFO=6, XR_TYPE_FRAME_WAIT_INFO=33, XR_TYPE_FRAME_STATE=44, XR_TYPE_FRAME_BEGIN_INFO=46, XR_TYPE_SESSION_BEGIN_INFO=10, XR_TYPE_FRAME_END_INFO=12, XR_TYPE_SWAPCHAIN_CREATE_INFO=9, XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED=18, XR_TYPE_SWAPCHAIN_IMAGE_VULKAN_KHR=1000025001, XR_TYPE_GRAPHICS_BINDING_VULKAN_KHR=1000025000, XR_TYPE_VULKAN_INSTANCE_CREATE_INFO_KHR=1000029000, XR_TYPE_VULKAN_DEVICE_CREATE_INFO_KHR=1000029001, XR_TYPE_VULKAN_GRAPHICS_DEVICE_GET_INFO_KHR=1000029003, XR_TYPE_GRAPHICS_REQUIREMENTS_VULKAN_KHR=1000025002, XR_TYPE_ACTION_SET_CREATE_INFO=28, XR_TYPE_ACTION_CREATE_INFO=29, XR_TYPE_ACTION_SPACE_CREATE_INFO=30, XR_TYPE_SESSION_ACTION_SETS_ATTACH_INFO=31, XR_TYPE_ACTIONS_SYNC_INFO=48, XR_TYPE_ACTION_STATE_GET_INFO=49, XR_TYPE_ACTION_STATE_BOOLEAN=50, XR_TYPE_ACTION_STATE_FLOAT=51, XR_TYPE_ACTION_STATE_VECTOR2F=52, XR_TYPE_ACTION_STATE_POSE=53, XR_TYPE_HAPTIC_VIBRATION=57, XR_TYPE_HAPTIC_ACTION_INFO=58, XR_TYPE_BOUND_SOURCES_FOR_ACTION_ENUMERATE_INFO=40, XR_TYPE_INPUT_SOURCE_LOCALIZED_NAME_GET_INFO=45, XR_TYPE_INTERACTION_PROFILE_SUGGESTED_BINDING=28+100 };
enum { XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY=1, XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO=2, XR_REFERENCE_SPACE_TYPE_VIEW=1, XR_REFERENCE_SPACE_TYPE_LOCAL=2, XR_REFERENCE_SPACE_TYPE_STAGE=3, XR_SESSION_STATE_IDLE=1, XR_SESSION_STATE_READY=2, XR_SESSION_STATE_SYNCHRONIZED=3, XR_SESSION_STATE_VISIBLE=4, XR_SESSION_STATE_FOCUSED=5, XR_SESSION_STATE_STOPPING=6, XR_SESSION_STATE_LOSS_PENDING=7, XR_SESSION_STATE_EXITING=8 };
enum { XR_ACTION_TYPE_BOOLEAN_INPUT=1, XR_ACTION_TYPE_FLOAT_INPUT=2, XR_ACTION_TYPE_VECTOR2F_INPUT=3, XR_ACTION_TYPE_POSE_INPUT=4, XR_ACTION_TYPE_VIBRATION_OUTPUT=100 };

typedef struct { int32_t x,y; } XrExtent2Di;
typedef struct { float x,y; } XrVector2f;
typedef struct { float x,y,z; } XrVector3f;
typedef struct { float x,y,z,w; } XrQuaternionf;
typedef struct { XrQuaternionf orientation; XrVector3f position; } XrPosef;
typedef struct { XrPosef pose; struct { float angleLeft,angleRight,angleUp,angleDown; } fov; } XrView;
typedef struct { int type; const void* next; uint32_t recommendedImageRectWidth; uint32_t recommendedImageRectHeight; uint32_t maxImageRectWidth; uint32_t maxImageRectHeight; uint32_t recommendedSwapchainSampleCount; uint32_t maxSwapchainSampleCount; } XrViewConfigurationView;

typedef struct { char applicationName[128]; uint32_t applicationVersion; char engineName[128]; uint32_t engineVersion; XrVersion apiVersion; } XrApplicationInfo;
typedef struct { int type; const void* next; XrFlags64 createFlags; XrApplicationInfo applicationInfo; uint32_t enabledApiLayerCount; const char* const* enabledApiLayerNames; uint32_t enabledExtensionCount; const char* const* enabledExtensionNames; } XrInstanceCreateInfo;
typedef struct { int type; const void* next; int formFactor; } XrSystemGetInfo;
typedef struct { int type; const void* next; XrSystemId systemId; uint64_t createFlags; const void* graphicsBinding; } XrSessionCreateInfo;
typedef struct { int type; const void* next; XrSession session; int state; XrTime time; } XrEventDataSessionStateChanged;
typedef struct { int type; const void* next; int primaryViewConfigurationType; } XrSessionBeginInfo;
typedef struct { int type; const void* next; XrSystemId systemId; uint64_t createFlags; void* pfnGetInstanceProcAddr; const void* vulkanCreateInfo; const void* vulkanAllocator; } XrVulkanInstanceCreateInfoKHR;
typedef struct { int type; const void* next; XrSystemId systemId; XrFlags64 createFlags; void* pfnGetInstanceProcAddr; uint64_t vulkanPhysicalDevice; const void* vulkanCreateInfo; const void* vulkanAllocator; } XrVulkanDeviceCreateInfoKHR;
typedef struct { int type; const void* next; XrSystemId systemId; uint64_t vulkanInstance; } XrVulkanGraphicsDeviceGetInfoKHR;
typedef struct { int type; void* next; XrVersion minApiVersionSupported; XrVersion maxApiVersionSupported; } XrGraphicsRequirementsVulkanKHR;
typedef struct { int type; void* next; XrTime predictedDisplayTime; XrDuration predictedDisplayPeriod; XrBool32 shouldRender; } XrFrameState;
typedef struct { int type; const void* next; } XrFrameWaitInfo;
typedef struct { int type; const void* next; } XrFrameBeginInfo;
typedef struct { int type; const void* next; XrTime displayTime; int environmentBlendMode; uint32_t layerCount; const void* const* layers; } XrFrameEndInfo;
typedef struct { int type; const void* next; int referenceSpaceType; XrPosef poseInReferenceSpace; } XrReferenceSpaceCreateInfo;
typedef int XrViewConfigurationType;
typedef struct { int type; const void* next; int viewConfigurationType; XrTime displayTime; XrSpace space; } XrViewLocateInfo;
typedef struct { int type; const void* next; XrFlags64 createFlags; XrFlags64 usageFlags; int64_t format; int32_t sampleCount; int32_t width,height; int32_t faceCount; int32_t arraySize; int32_t mipCount; } XrSwapchainCreateInfo;
typedef struct { int type; void* next; } XrSwapchainImageBaseHeader;
typedef struct { int type; void* next; uint64_t image; } XrSwapchainImageVulkanKHR;
typedef struct { int type; void* next; uint64_t systemId; uint32_t vendorId; char systemName[256]; struct { uint32_t maxSwapchainImageWidth; uint32_t maxSwapchainImageHeight; uint32_t maxLayerCount; } graphicsProperties; struct { uint32_t orientationTracking; uint32_t positionTracking; } trackingProperties; } XrSystemProperties;

typedef struct { int type; const void* next; char actionSetName[64]; char localizedActionSetName[128]; uint32_t priority; } XrActionSetCreateInfo;
typedef struct { int type; const void* next; char actionName[64]; char localizedActionName[128]; int actionType; uint32_t countSubactionPaths; const XrPath* subactionPaths; } XrActionCreateInfo;
typedef struct { int type; const void* next; XrAction action; XrPath subactionPath; XrSpace referenceSpace; XrPosef poseInActionSpace; } XrActionSpaceCreateInfo;
typedef struct { int type; const void* next; uint32_t countActionSets; const XrActionSet* actionSets; } XrSessionActionSetsAttachInfo;
typedef struct { int type; const void* next; uint32_t countActiveActionSets; const void* activeActionSets; } XrActionsSyncInfo;
typedef struct { int type; const void* next; XrAction action; XrPath subactionPath; } XrActionStateGetInfo;
typedef struct { int type; void* next; XrBool32 currentState; XrBool32 changedSinceLastSync; XrTime lastChangeTime; uint32_t isActive; } XrActionStateBoolean;
typedef struct { int type; void* next; float currentState; XrBool32 changedSinceLastSync; XrTime lastChangeTime; uint32_t isActive; } XrActionStateFloat;
typedef struct { int type; void* next; XrVector2f currentState; XrBool32 changedSinceLastSync; XrTime lastChangeTime; uint32_t isActive; } XrActionStateVector2f;
typedef struct { int type; void* next; XrBool32 isActive; } XrActionStatePose;
typedef struct { int type; const void* next; XrAction action; XrPath subactionPath; } XrHapticActionInfo;
typedef struct { int type; const void* next; XrDuration duration; float frequency; float amplitude; } XrHapticVibration;
typedef struct { int type; const void* next; XrAction action; } XrBoundSourcesForActionEnumerateInfo;
typedef struct { int type; const void* next; XrPath sourcePath; uint32_t whichComponents; } XrInputSourceLocalizedNameGetInfo;
typedef struct { int type; const void* next; XrPath interactionProfile; uint32_t countSuggestedBindings; const void* suggestedBindings; } XrInteractionProfileSuggestedBinding;

typedef XrResult (*PFN_xrVoidFunction)(void);
typedef XrResult (*PFN_xrGetInstanceProcAddr)(XrInstance,const char*,PFN_xrVoidFunction*);
#define XRAPI_ATTR
#define XRAPI_CALL
#ifdef __cplusplus
}
#endif
