# PhoneXR v0.8 — Vulkan reuse analysis

The supplied HLVR payload contains:

- `librendersystemvulkan.so` (~10.3 MB)
- `libvulkan_freedreno_hlvr.so` (~17.4 MB)

Important finding: these two payload libraries are **Linux/SteamRT ARM64 ELF binaries**, not Android NDK shared libraries. The render system depends on glibc/libstdc++ and X11 (`libxcb.so.1`); the Freedreno ICD depends on Linux DRM/X11/Wayland libraries and exports the Vulkan ICD entry points (`vk_icdGetInstanceProcAddr`, `vk_icdGetPhysicalDeviceProcAddr`, `vk_icdNegotiateLoaderICDInterfaceVersion`).

Therefore v0.8 does **not** attempt to dlopen the Linux ICD directly from Android. Doing so would be unsafe and would fail on a stock Android userspace because the required Linux desktop ABI is absent.

The correct reuse boundary is the Vulkan API boundary:

`HLVR render system -> Vulkan loader/API -> Android Vulkan driver`

PhoneXR remains between the OpenXR application-facing layer and the Android Vulkan device/compositor. The Linux Freedreno ICD is retained as a reference for HLVR-specific behavior, but is not treated as the Android driver.
