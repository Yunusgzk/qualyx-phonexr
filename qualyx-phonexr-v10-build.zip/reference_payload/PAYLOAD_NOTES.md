# Supplied Qualyx payload notes

This directory contains the ARM64 native libraries supplied with the user's `lib.zip`, retained as a reference payload for PhoneXR integration and ABI checks. The complete engine asset tree is intentionally not duplicated here because the source archive is the authoritative asset package.

## Important findings

- `libhlvr_host.so`: Android ARM64, NDK r27c, API 29; imports `libopenxr_loader.so`, Vulkan, NativeWindow, AAudio and Android logging.
- The host explicitly resolves OpenXR functions for actions, controller poses, haptics, paths, frame lifecycle and Vulkan swapchains.
- `libopenxr_loader.so` in the supplied payload is Android ARM64 and was built with NDK r23c. PhoneXR's patch workflow replaces this file with the PhoneXR runtime.
- `libhlvr_bin.so` is a Linux/SteamRT ARM64 PIE and is not directly loadable as an Android shared library; it remains reference data, not an Android JNI dependency.
- `libquest_platform.so` and `libquest_exec.so` are retained for compatibility analysis but are not blindly loaded by PhoneXR.

The engine manifest remains separately referenced by the original payload archive.
